<script type="text/javascript">
	if(document.getElementById("progressbardiv")){
		document.getElementById("progressbardiv").style.display="none";
	}
</script>
</body>
</html>